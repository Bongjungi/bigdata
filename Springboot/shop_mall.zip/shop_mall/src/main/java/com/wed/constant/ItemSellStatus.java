package com.wed.constant;

public enum ItemSellStatus {
	SELL,SOLD_OUT
}
