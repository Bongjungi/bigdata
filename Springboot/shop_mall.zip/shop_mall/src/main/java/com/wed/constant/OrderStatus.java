package com.wed.constant;

public enum OrderStatus {
	ORDER, CANCEL
}
