package com.wed;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopMallApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopMallApplication.class, args);
	}

}
