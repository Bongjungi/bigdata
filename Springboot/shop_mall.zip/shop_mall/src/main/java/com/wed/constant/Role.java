package com.wed.constant;

public enum Role {
	USER, ADMIN
}
