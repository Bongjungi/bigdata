package com.wed;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopMallApplicationTests {

	@Test
	void contextLoads() {
	}

}
